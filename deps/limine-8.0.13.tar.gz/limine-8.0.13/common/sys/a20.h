#ifndef SYS__A20_H__
#define SYS__A20_H__

#include <stdbool.h>

bool a20_check(void);
bool a20_enable(void);

#endif
