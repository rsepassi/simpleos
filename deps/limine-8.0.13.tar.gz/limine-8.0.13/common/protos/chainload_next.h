#ifndef PROTOS__CHAINLOAD_NEXT_H__
#define PROTOS__CHAINLOAD_NEXT_H__

#include <stdnoreturn.h>

noreturn void chainload_next(char *config, char *cmdline);

#endif
